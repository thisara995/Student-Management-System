<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Information and CSS Links -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .container {
            margin-top: 2rem; /* Adjust this value as needed */
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="layoutSidenav">
        <!-- Sidebar -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="layoutSidenav_content">
            <!-- Main Content -->
            <main>
                <h1 class="mt-4 px-4">COURSE SECTION</h1>
                <ol class="breadcrumb mb-4 px-4">
                    <li class="breadcrumb-item"><a href="">Course</a></li>
                    <li class="breadcrumb-item active">Add Course</li>
                </ol>
                <div class="container mb-4 mt-2" style="max-width: 50rem;">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="text-center">Course Details</h5>
                        </div>
                        <div class="card-body p-4">
                            <h6 class="card-title mb-3"><strong>Course Name: </strong><?php echo e($course->name); ?></h6>
                            <h6 class="card-title mb-3"><strong>Title: </strong><?php echo e($course->title); ?></h6>
                            <p class="card-text mb-3"><strong>Description: </strong><?php echo e($course->description); ?></p>
                            <p class="card-text mb-3"><strong>Syllabus: </strong><?php echo e($course->syllabus); ?></p>
                            <p class="card-text mb-3"><strong>Teacher: </strong><?php echo e($course->teacher->name); ?></p>
                            <a href="<?php echo e(route('courses.list')); ?>" class="btn btn-outline-primary btn-block mt-4">Back to Courses</a>
                        </div>
                        <div class="card-footer text-muted text-center">
                            <small>Updated <?php echo e($course->updated_at->diffForHumans()); ?></small>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- Scripts -->
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Student-Management-System\student-management-system\resources\views/course/view-course.blade.php ENDPATH**/ ?>