<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Information and CSS Links -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="sb-nav-fixed">
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="layoutSidenav">
        <!-- Sidebar -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="layoutSidenav_content">
                        <!-- Main Content -->
                        <main>
                            <div class="container-fluid px-4">
                                <h1 class="mt-4">STUDENT SECTION</h1>
                                <ol class="breadcrumb mb-4">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/students')); ?>">Student</a></li>
                                    <li class="breadcrumb-item active">View Students</li>
                                </ol>

                                <?php if(session('status')): ?>
                                    <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                                <?php endif; ?> 
                                <div class="card mb-4">
                                    <div class="card-body">
                                        <table id="datatablesSimple">
                                            <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Student Name</th>
                                                    <th>Age</th>
                                                    <th>Address</th>
                                                    <th>Mobile</th>
                                                    <th>Parent</th>
                                                    <th>Parent Mobile</th>
                                                    <th>Action</th> 
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Student Name</th>
                                                    <th>Age</th>
                                                    <th>Address</th>
                                                    <th>Mobile</th>
                                                    <th>Parent</th>
                                                    <th>Parent Mobile</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->age); ?></td>
                                    <td><?php echo e($item->address); ?></td>
                                    <td><?php echo e($item->mobile); ?></td>
                                    <td><?php echo e($item->parent); ?></td>
                                    <td><?php echo e($item->parent_mobile); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/students/'.$item->id.'/view')); ?>" class="btn btn-secondary btn-sm">View</a>
                                        <a href="<?php echo e(url('/students/'.$item->id.'/edit')); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        
                                        <!-- Update delete form -->
                                        <form action="<?php echo e(url('/students/'.$item->id.'/delete')); ?>" method="POST" id="delete-form-<?php echo e($item->id); ?>" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($item->id); ?>)">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>

                        <!-- Footer -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    
    <!-- Scripts -->
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
function confirmDelete(studentId) {
    swal({
        title: "Are you sure?",
        text: "You will not be able to recover this student's data!",
        icon: "warning",
        dangerMode: true,
        buttons: true,
        
    })
    .then((willDelete) => {
        if (willDelete) {
            // If the user confirms, submit the form
            document.getElementById('delete-form-' + studentId).submit();
            swal("Deleted!", "The student has been deleted.", "success");
        } else {
            swal("The student data is safe!");
        }
    });
}
</script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Student-Management-System\student-management-system\resources\views/students/list-students.blade.php ENDPATH**/ ?>